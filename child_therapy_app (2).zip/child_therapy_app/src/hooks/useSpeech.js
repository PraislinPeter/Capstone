import { useCallback } from "react";

/**
 * useSpeech — DISABLED.
 *
 * All text-to-speech output has been removed from the child app.
 * This hook is kept as a no-op so existing imports (CompanionBot, etc.)
 * continue to work without any code changes elsewhere.
 *
 * If you ever want TTS back, restore the original Web Speech API
 * implementation here — no other files need to change.
 */
export default function useSpeech() {
  const speak = useCallback((_text, onEnd) => {
    // Narration disabled — immediately fire the end callback so any
    // component relying on "speech finished" animations keeps working.
    if (onEnd) onEnd();
  }, []);

  const stop = useCallback(() => {
    // No-op — nothing is ever speaking.
  }, []);

  const isSpeaking = false;

  return { speak, stop, isSpeaking };
}
