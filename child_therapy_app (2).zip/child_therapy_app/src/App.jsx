import React, { useState, useCallback, useEffect, useRef } from "react";
import useCamera from "./hooks/useCamera";
import HardwareAPI from "./api/hardware";
import HomeScreen from "./screens/HomeScreen";
import TextureBookScreen from "./screens/TextureBookScreen";
import StressCheckScreen from "./screens/StressCheckScreen";
import BreatheScreen from "./screens/BreatheScreen";

/**
 * App — root component with stress-aware routing.
 *
 * Stress detection:
 *   - Tracks consecutive wrong answers across texture questions
 *   - 3+ wrong in a row → auto-routes to stress-check with "struggling" context
 *   - After all textures complete → gentle "Great job!" check-in
 *   - Child can also manually access break from HomeScreen
 */
export default function App() {
  const { start, stop, captureFrame } = useCamera();
  const [screen, setScreen] = useState("home");
  const [sessionLog, setSessionLog] = useState([]);
  const [stressSignals, setStressSignals] = useState(0);
  const [stressReason, setStressReason] = useState(null);
  const [activityComplete, setActivityComplete] = useState(false);

  const streamingIntervalRef = useRef(null);

  const startStreamingLoop = useCallback(() => {
    if (streamingIntervalRef.current) return;
    streamingIntervalRef.current = setInterval(() => {
      try {
        const frame = captureFrame();
        if (frame) HardwareAPI.sendVideoFrame(frame);
      } catch {}
    }, 200);
  }, [captureFrame]);

  const stopStreamingLoop = useCallback(() => {
    if (streamingIntervalRef.current) {
      clearInterval(streamingIntervalRef.current);
      streamingIntervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    const init = async () => {
      const params = new URLSearchParams(window.location.search);
      const patientId = parseInt(params.get("patient"), 10) || 1;
      console.log(`[APP] Starting session for patient ${patientId}`);
      try {
        if (!mounted) return;
        await HardwareAPI.startSession(patientId);
        await start();
        startStreamingLoop();
      } catch (err) {
        console.error("[APP] Init failed:", err);
      }
    };
    init();
    return () => { mounted = false; stopStreamingLoop(); stop(); HardwareAPI.endSession(); };
  }, [start, stop, startStreamingLoop, stopStreamingLoop]);

  const navigate = useCallback((target) => {
    HardwareAPI.logEvent("navigate", { to: target });
    setScreen(target);
  }, []);

  const logEvent = useCallback((type, data) => {
    setSessionLog((prev) => [...prev, { type, ...data, time: Date.now() }]);
  }, []);

  // Called by TextureBookScreen on every question answer
  const handleStressSignal = useCallback((isCorrect) => {
    if (!isCorrect) {
      setStressSignals((prev) => {
        const next = prev + 1;
        if (next >= 3) {
          // 3 consecutive wrong → auto-break
          setStressReason("struggling");
          setScreen("stress-check");
          return 0;
        }
        return next;
      });
    } else {
      // Correct answer resets the counter
      setStressSignals(0);
    }
  }, []);

  const handleActivityComplete = useCallback(() => {
    setActivityComplete(true);
    setStressReason("check-in");
    setScreen("stress-check");
  }, []);

  const handleBreakComplete = useCallback(() => {
    setStressSignals(0);
    setStressReason(null);
    setScreen("home");
  }, []);

  return (
    <>
      <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet" />

      {screen === "home" && (
        <HomeScreen onNavigate={navigate} activityComplete={activityComplete} />
      )}
      {screen === "texture-book" && (
        <TextureBookScreen
          onNavigate={navigate}
          onLogEvent={logEvent}
          onStressSignal={handleStressSignal}
          onActivityComplete={handleActivityComplete}
        />
      )}
      {screen === "stress-check" && (
        <StressCheckScreen
          onNavigate={navigate}
          reason={stressReason}
          onBreakComplete={handleBreakComplete}
        />
      )}
      {screen === "breathe" && (
        <BreatheScreen
          onNavigate={navigate}
          onBreakComplete={handleBreakComplete}
        />
      )}
    </>
  );
}
