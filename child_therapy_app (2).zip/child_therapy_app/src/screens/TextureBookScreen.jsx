import React, { useState, useEffect, useCallback } from "react";
import palette from "../constants/palette";
import TEXTURES from "../constants/textures";
import HardwareAPI from "../api/hardware";
import BackButton from "../components/BackButton";
import ProgressDots from "../components/ProgressDots";
import CompanionBot from "../components/CompanionBot";
import useKeypad from "../hooks/useKeypad";

/**
 * TextureBookScreen — Phase 1: Interactive texture exploration.
 *
 * Input: Screen tap OR ESP32 numpad (keys 1-3 map to options).
 * For dev testing: press 1, 2, 3 on keyboard to simulate numpad.
 *
 * Flow per texture:
 *   1. Bot asks child to find and touch the texture → touch detected
 *   2. Knowledge questions with numbered options (tap or numpad)
 *   3. Wrong → teaching prompt → reset → retry
 *   4. After all questions → "How do you feel?" with emoji options
 *   5. Next texture
 */

const FEELING_OPTIONS = [
  { id: "happy", label: "Happy", icon: "😊" },
  { id: "sad", label: "Sad", icon: "😢" },
  { id: "calm", label: "Calm", icon: "😌" },
];

export default function TextureBookScreen({ onNavigate, onLogEvent, onStressSignal, onActivityComplete }) {
  const [textureIndex, setTextureIndex] = useState(0);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [phase, setPhase] = useState("intro"); // intro | touch | detecting | question | wrong | feeling | done
  const [selectedId, setSelectedId] = useState(null);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [childFeeling, setChildFeeling] = useState(null);

  const [botMessage, setBotMessage] = useState("");
  const [botMood, setBotMood] = useState("neutral");
  const [botOptions, setBotOptions] = useState(null);

  const tex = TEXTURES[textureIndex];
  const questions = tex.questions || [];
  const currentQ = questions[questionIndex];
  const isTouchQuestion = currentQ?.type === "touch";

  // ── Get current selectable options ──
  const activeOptions = phase === "question" && currentQ && !isTouchQuestion
    ? currentQ.options
    : phase === "feeling"
    ? FEELING_OPTIONS
    : null;

  // ── Keypad handler — maps key 1/2/3 to option selection ──
  const handleKeypadPress = useCallback((keyNumber) => {
    if (!activeOptions || keyNumber < 1 || keyNumber > activeOptions.length) return;

    const option = activeOptions[keyNumber - 1];
    if (!option) return;

    if (phase === "question") {
      handleAnswer(option.id);
    } else if (phase === "feeling") {
      handleFeelingSelect(option.id);
    }
  }, [activeOptions, phase]);

  // Subscribe to keypad (enabled only when options are visible)
  useKeypad(handleKeypadPress, !!activeOptions && phase !== "wrong");

  // ── Reset on new texture ──
  useEffect(() => {
    setQuestionIndex(0);
    setPhase("intro");
    setSelectedId(null);
    setQuestionsAnswered(0);
    setChildFeeling(null);
    setBotMessage(`Let's explore ${tex.name}! ${tex.emoji}`);
    setBotMood("happy");
    setBotOptions(null);

    const timer = setTimeout(() => {
      if (questions[0]?.type === "touch") {
        setPhase("touch");
        setBotMessage(questions[0].text);
        setBotMood("encouraging");
      } else {
        setPhase("question");
        setBotMessage(questions[0]?.text || `Touch the ${tex.name}!`);
        setBotMood("thinking");
      }
    }, 1500);

    return () => clearTimeout(timer);
  }, [textureIndex]);

  // ── Touch detection ──
  const handleStartTouch = async () => {
    setPhase("detecting");
    setBotMessage("I can see you're exploring... take your time!");
    setBotMood("encouraging");
    setBotOptions(null);

    HardwareAPI.logEvent("texture_touch_start", { texture: tex.id });

    const result = await HardwareAPI.simulateTouch();
    if (result.detected) {
      HardwareAPI.logGameEvent("texture", { texture_id: tex.id, duration_ms: 2000 });
      if (onLogEvent) onLogEvent("texture", { texture: tex.id });
      setTimeout(() => advanceToNextQuestion(), 1000);
    }
  };

  // ── Answer a knowledge question ──
  const handleAnswer = (optionId) => {
    if (phase !== "question") return;
    setSelectedId(optionId);
    const correct = optionId === currentQ.correctId;

    // Signal stress tracker in App.jsx — every answer counts
    if (onStressSignal) onStressSignal(correct);

    HardwareAPI.logGameEvent("texture_question", {
      texture_id: tex.id,
      question_id: currentQ.id,
      selected: optionId,
      expected: currentQ.correctId,
      correct,
    });

    if (correct) {
      setQuestionsAnswered((c) => c + 1);
      setBotMessage("Yes! That's right! ✨");
      setBotMood("celebrating");
      setBotOptions(null);
      setTimeout(() => advanceToNextQuestion(), 1800);
    } else {
      setPhase("wrong");
      setBotMessage(currentQ.teachingPrompt + " Try again!");
      setBotMood("encouraging");
      setTimeout(() => {
        setSelectedId(null);
        setPhase("question");
        setBotMessage(currentQ.text);
        setBotMood("thinking");
      }, 2500);
    }
  };

  // ── Feeling selection ──
  const handleFeelingSelect = (feelingId) => {
    setChildFeeling(feelingId);
    setPhase("done");
    setBotOptions(null);

    HardwareAPI.logGameEvent("texture_feeling", {
      texture_id: tex.id,
      feeling: feelingId,
      questions_answered: questionsAnswered,
    });

    setBotMessage("Thank you for sharing how you feel! Great job! 🌟");
    setBotMood("celebrating");
  };

  // ── Advance to next question or feeling ──
  const advanceToNextQuestion = () => {
    const nextIdx = questionIndex + 1;
    if (nextIdx < questions.length) {
      setQuestionIndex(nextIdx);
      setSelectedId(null);
      const nextQ = questions[nextIdx];
      if (nextQ.type === "touch") {
        setPhase("touch");
        setBotMessage(nextQ.text);
        setBotMood("encouraging");
      } else {
        setPhase("question");
        setBotMessage(nextQ.text);
        setBotMood("thinking");
      }
      setBotOptions(null);
    } else {
      setPhase("feeling");
      setBotMessage(`You explored ${tex.name}! How does touching it make YOU feel?`);
      setBotMood("thinking");
      setBotOptions(FEELING_OPTIONS);
    }
  };

  // ── Next texture ──
  const handleNextTexture = () => {
    if (textureIndex < TEXTURES.length - 1) {
      setTextureIndex((i) => i + 1);
    } else {
      if (onActivityComplete) onActivityComplete();
      else onNavigate("home");
    }
  };

  return (
    <div style={{
      minHeight: "100vh", background: palette.bg, fontFamily: "'Nunito', sans-serif",
      padding: "32px 32px 160px", display: "flex", flexDirection: "column", alignItems: "center",
    }}>
      <div style={{ width: "100%", maxWidth: 540 }}>
        <BackButton onClick={() => onNavigate("home")} />
      </div>

      <div style={{ maxWidth: 540, margin: "16px auto 0", textAlign: "center", width: "100%" }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <p style={{ fontSize: 13, color: palette.gray, margin: 0, fontWeight: 700 }}>
            Texture {textureIndex + 1} of {TEXTURES.length}
          </p>
          <div style={{
            background: palette.mintLight, borderRadius: 12, padding: "3px 12px",
            fontSize: 12, fontWeight: 800, color: palette.dark,
          }}>
            {questionsAnswered} answered
          </div>
        </div>

        <h1 style={{ fontSize: 28, fontWeight: 900, color: palette.dark, margin: "0 0 6px" }}>
          {tex.emoji} {tex.name}
        </h1>
        <p style={{ fontSize: 14, color: palette.gray, margin: "0 0 4px", fontWeight: 600 }}>
          {tex.description}
        </p>
        <p style={{ fontSize: 12, color: palette.gray, margin: "0 0 20px", fontStyle: "italic" }}>
          {tex.sensoryCategory}
        </p>

        {/* ── Texture card ── */}
        <div
          onClick={phase === "touch" ? handleStartTouch : undefined}
          style={{
            width: "100%", maxWidth: 380, height: 200, borderRadius: 24,
            background: phase === "done" ? palette.dark : `linear-gradient(145deg, ${tex.color}, ${tex.color}CC)`,
            margin: "0 auto 20px", display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center", gap: 10,
            cursor: phase === "touch" ? "pointer" : "default",
            boxShadow: `0 10px 36px ${tex.color}40`,
            transition: "all 0.5s ease", position: "relative",
          }}
        >
          {phase === "touch" && (
            <>
              <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 18, padding: "8px 20px" }}>
                <span style={{ color: palette.white, fontSize: 14, fontWeight: 600 }}>Tap here or touch the book</span>
              </div>
              <span style={{ fontSize: 44 }}>{tex.emoji}</span>
              <span style={{ fontSize: 20, fontWeight: 800, color: palette.white }}>{tex.name}</span>
            </>
          )}
          {phase === "detecting" && (
            <>
              <div style={{ width: 40, height: 40, borderRadius: "50%", border: "4px solid rgba(255,255,255,0.3)", borderTopColor: palette.white, animation: "spin 0.8s linear infinite" }} />
              <span style={{ fontSize: 18, fontWeight: 800, color: palette.white }}>Detecting touch...</span>
            </>
          )}
          {(phase === "question" || phase === "wrong" || phase === "feeling") && (
            <div style={{ padding: "16px 24px", textAlign: "center" }}>
              <span style={{ fontSize: 36, display: "block", marginBottom: 8 }}>{tex.emoji}</span>
              <div style={{ background: "rgba(255,255,255,0.9)", borderRadius: 16, padding: "10px 18px" }}>
                <span style={{ fontSize: 14, fontWeight: 800, color: palette.dark }}>✅ Touched! Answering questions...</span>
              </div>
            </div>
          )}
          {phase === "intro" && (
            <>
              <span style={{ fontSize: 50 }}>{tex.emoji}</span>
              <span style={{ fontSize: 22, fontWeight: 800, color: palette.white }}>{tex.name}</span>
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.8)", fontWeight: 600 }}>Get ready to explore!</span>
            </>
          )}
          {phase === "done" && (
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 44, marginBottom: 8 }}>
                {childFeeling === "happy" ? "😊" : childFeeling === "sad" ? "😢" : "😌"}
              </div>
              <div style={{ background: palette.white, borderRadius: 16, padding: "12px 24px" }}>
                <span style={{ fontSize: 16, fontWeight: 800, color: palette.dark }}>
                  {questionsAnswered} questions · Feeling: {childFeeling} ✨
                </span>
              </div>
            </div>
          )}
        </div>

        {/* ── Numpad hint ── */}
        {(phase === "question" || phase === "feeling") && (
          <div style={{
            background: palette.purpleLight, borderRadius: 12, padding: "6px 14px",
            margin: "0 auto 12px", display: "inline-flex", alignItems: "center", gap: 6,
          }}>
            <span style={{ fontSize: 14 }}>🔢</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: palette.purple }}>
              Press 1, 2{activeOptions?.length > 2 ? ", 3" : ""} on the numpad — or tap below
            </span>
          </div>
        )}

        {/* ── Knowledge question options with numbers ── */}
        {phase === "question" && currentQ && !isTouchQuestion && (
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginBottom: 16 }}>
            {currentQ.options.map((opt, idx) => {
              const isSelected = selectedId === opt.id;
              const keyNum = idx + 1;

              return (
                <button
                  key={opt.id}
                  onClick={() => handleAnswer(opt.id)}
                  style={{
                    minWidth: 140, padding: "14px 14px", borderRadius: 20,
                    border: `3px solid ${palette.mintLight}`,
                    background: isSelected ? palette.mintLight : palette.white,
                    cursor: "pointer", display: "flex", flexDirection: "column",
                    alignItems: "center", gap: 6, fontFamily: "'Nunito', sans-serif",
                    transition: "all 0.2s", boxShadow: "0 3px 12px rgba(0,0,0,0.06)",
                    position: "relative",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-3px) scale(1.03)")}
                  onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
                >
                  {/* Key number badge */}
                  <div style={{
                    position: "absolute", top: -8, left: -8, width: 26, height: 26,
                    borderRadius: "50%", background: palette.purple, color: palette.white,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 13, fontWeight: 900, boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
                  }}>
                    {keyNum}
                  </div>
                  <span style={{ fontSize: 28 }}>{opt.icon}</span>
                  <span style={{ fontSize: 13, fontWeight: 800, color: palette.dark }}>{opt.label}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* ── Wrong answer teaching ── */}
        {phase === "wrong" && (
          <div style={{
            background: palette.purpleLight, borderRadius: 16, padding: "12px 18px",
            margin: "0 auto 14px", maxWidth: 400, animation: "fadeIn 0.3s ease",
          }}>
            <p style={{ fontSize: 14, fontWeight: 700, color: palette.dark, margin: 0 }}>{currentQ.teachingPrompt}</p>
            <p style={{ fontSize: 12, fontWeight: 600, color: palette.gray, margin: "6px 0 0" }}>Try again! 💜</p>
          </div>
        )}

        {/* ── Feeling options with numbers ── */}
        {phase === "feeling" && (
          <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap", marginBottom: 16 }}>
            {FEELING_OPTIONS.map((opt, idx) => {
              const styles = {
                happy: { bg: "#FFF8E1", border: "#FFC107", text: "#F57F17" },
                sad: { bg: "#E3F2FD", border: "#64B5F6", text: "#1565C0" },
                calm: { bg: "#E8F5E9", border: "#81C784", text: "#2E7D32" },
              };
              const s = styles[opt.id];
              const keyNum = idx + 1;

              return (
                <button
                  key={opt.id}
                  onClick={() => handleFeelingSelect(opt.id)}
                  style={{
                    width: 120, padding: "18px 10px", borderRadius: 22,
                    border: `3px solid ${s.border}`, background: s.bg,
                    cursor: "pointer", display: "flex", flexDirection: "column",
                    alignItems: "center", gap: 6, fontFamily: "'Nunito', sans-serif",
                    transition: "all 0.15s", position: "relative",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-4px) scale(1.05)")}
                  onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
                >
                  {/* Key number badge */}
                  <div style={{
                    position: "absolute", top: -8, left: -8, width: 26, height: 26,
                    borderRadius: "50%", background: palette.purple, color: palette.white,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 13, fontWeight: 900, boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
                  }}>
                    {keyNum}
                  </div>
                  <span style={{ fontSize: 40 }}>{opt.icon}</span>
                  <span style={{ fontSize: 16, fontWeight: 800, color: s.text }}>{opt.label}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* ── Next texture ── */}
        {phase === "done" && (
          <button
            onClick={handleNextTexture}
            style={{
              background: palette.mint, color: palette.white, border: "none", borderRadius: 28,
              padding: "14px 40px", fontSize: 20, fontWeight: 800, cursor: "pointer",
              fontFamily: "'Nunito', sans-serif", boxShadow: "0 4px 16px rgba(126,206,193,0.4)",
              marginBottom: 16,
            }}
          >
            {textureIndex < TEXTURES.length - 1 ? "Next Texture →" : "All Done! 🎉"}
          </button>
        )}

        {/* Question progress dots */}
        {(phase === "question" || phase === "wrong" || phase === "feeling") && (
          <div style={{ display: "flex", gap: 6, justifyContent: "center", margin: "0 0 12px" }}>
            {questions.map((q, i) => (
              <div key={q.id} style={{
                width: i === questionIndex ? 24 : 10, height: 10, borderRadius: 5,
                background: i < questionIndex ? palette.mint : i === questionIndex ? palette.pink : palette.gray + "40",
                transition: "all 0.3s",
              }} />
            ))}
            <div style={{
              width: phase === "feeling" ? 24 : 10, height: 10, borderRadius: 5,
              background: phase === "done" ? palette.mint : phase === "feeling" ? palette.pink : palette.gray + "40",
            }} />
          </div>
        )}

        <ProgressDots total={TEXTURES.length} currentIndex={textureIndex} activeColor={palette.mint} doneColor={palette.mintLight} />
      </div>

      <CompanionBot
        message={botMessage}
        options={phase === "feeling" ? FEELING_OPTIONS : null}
        onSelect={phase === "feeling" ? handleFeelingSelect : undefined}
        mood={botMood}
        autoSpeak={true}
        visible={true}
        position="bottom"
      />

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-6px); } 75% { transform: translateX(6px); } }
      `}</style>
    </div>
  );
}
