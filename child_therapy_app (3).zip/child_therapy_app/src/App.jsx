import React, { useState, useCallback, useEffect } from "react";
import HardwareAPI from "./api/hardware";
import HomeScreen from "./screens/HomeScreen";
import TextureBookScreen from "./screens/TextureBookScreen";
import StressCheckScreen from "./screens/StressCheckScreen";
import BreatheScreen from "./screens/BreatheScreen";

/**
 * App — root component with stress-aware routing.
 *
 * Simulation mode: no camera, no WebSocket, no ESP32.
 * Child taps on screen to interact. Game events POST to backend.
 *
 * Stress detection:
 *   - Tracks consecutive wrong answers across texture questions
 *   - 3+ wrong in a row → auto-routes to stress-check
 *   - After all textures complete → gentle check-in
 *   - Manual break from HomeScreen
 */
export default function App() {
  const [screen, setScreen] = useState("home");
  const [stressSignals, setStressSignals] = useState(0);
  const [stressReason, setStressReason] = useState(null);
  const [activityComplete, setActivityComplete] = useState(false);

  // Auto-start session on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const patientId = parseInt(params.get("patient"), 10) || 1;
    console.log(`[APP] Starting session for patient ${patientId}`);
    HardwareAPI.startSession(patientId);
    return () => { HardwareAPI.endSession(); };
  }, []);

  const navigate = useCallback((target) => {
    HardwareAPI.logEvent("navigate", { to: target });
    setScreen(target);
  }, []);

  const logEvent = useCallback((type, data) => {
    console.log(`[APP] Event: ${type}`, data);
  }, []);

  // Called by TextureBookScreen on every question answer
  const handleStressSignal = useCallback((isCorrect) => {
    if (!isCorrect) {
      setStressSignals((prev) => {
        const next = prev + 1;
        if (next >= 3) {
          setStressReason("struggling");
          setScreen("stress-check");
          return 0;
        }
        return next;
      });
    } else {
      setStressSignals(0);
    }
  }, []);

  const handleActivityComplete = useCallback(() => {
    setActivityComplete(true);
    setStressReason("check-in");
    setScreen("stress-check");
  }, []);

  const handleBreakComplete = useCallback(() => {
    setStressSignals(0);
    setStressReason(null);
    setScreen("home");
  }, []);

  return (
    <>
      <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet" />

      {screen === "home" && (
        <HomeScreen onNavigate={navigate} activityComplete={activityComplete} />
      )}
      {screen === "texture-book" && (
        <TextureBookScreen
          onNavigate={navigate}
          onLogEvent={logEvent}
          onStressSignal={handleStressSignal}
          onActivityComplete={handleActivityComplete}
        />
      )}
      {screen === "stress-check" && (
        <StressCheckScreen
          onNavigate={navigate}
          reason={stressReason}
          onBreakComplete={handleBreakComplete}
        />
      )}
      {screen === "breathe" && (
        <BreatheScreen
          onNavigate={navigate}
          onBreakComplete={handleBreakComplete}
        />
      )}
    </>
  );
}
