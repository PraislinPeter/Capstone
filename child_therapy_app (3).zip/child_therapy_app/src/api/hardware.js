// ─── Hardware + Backend Integration Layer ───────────────────────────────────
//
// This version works for SIMULATION TESTING — no ESP32, no Pi camera needed.
// Touch is simulated (2s delay), keypad uses keyboard 1-9, game events POST to backend.
//
const BACKEND_URL = "http://localhost:8000";

let _patientId = null;
let _keypadCallbacks = [];

const safeJson = async (res) => {
  try { return await res.json(); } catch { return null; }
};

const HardwareAPI = {

  // ─── Session lifecycle ─────────────────────────────────────────────────
  startSession: async (patientId) => {
    _patientId = patientId;
    console.log(`[SESSION] Started for patient ${_patientId} (simulation mode)`);
    return `sim_session_${Date.now()}`;
  },

  endSession: async () => {
    console.log(`[SESSION] Ended for patient ${_patientId}`);
    _patientId = null;
  },

  getPatientId: () => _patientId,

  // ─── ESP32 Touch Sensor (simulated) ────────────────────────────────────
  subscribeTouchSensor: (callback) => {
    console.log("[HW] Touch sensor subscription (simulated)");
    return () => {};
  },

  simulateTouch: () => {
    return new Promise((resolve) => {
      setTimeout(() => resolve({ detected: true, pressure: 0.7 }), 2000);
    });
  },

  // ─── ESP32 Keypad (simulated via keyboard) ─────────────────────────────
  //
  // In PRODUCTION: ESP32 #2 sends key presses via WebSocket.
  // For TESTING: press 1-9 on your keyboard to simulate.
  //
  subscribeKeypad: (callback) => {
    _keypadCallbacks.push(callback);

    const keyHandler = (e) => {
      const num = parseInt(e.key);
      if (num >= 1 && num <= 9) {
        console.log(`[KEYPAD] Key pressed: ${num}`);
        _keypadCallbacks.forEach((cb) => cb(num));
      }
    };
    window.addEventListener("keydown", keyHandler);

    console.log("[KEYPAD] Listening — press 1-9 on keyboard to simulate numpad");

    return () => {
      _keypadCallbacks = _keypadCallbacks.filter((cb) => cb !== callback);
      window.removeEventListener("keydown", keyHandler);
    };
  },

  simulateKeyPress: (keyNumber) => {
    _keypadCallbacks.forEach((cb) => cb(keyNumber));
  },

  // ─── Game event logging via REST ───────────────────────────────────────
  logGameEvent: async (eventType, data = {}) => {
    if (!_patientId) {
      console.warn("[GAME] No patient — skipping event");
      return null;
    }

    const payload = {
      patient_id: _patientId,
      event_type: eventType,
      timestamp: new Date().toISOString(),
      ...data,
    };

    console.log(`[GAME] ${eventType}:`, payload);

    try {
      const res = await fetch(`${BACKEND_URL}/api/game-event`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const body = await safeJson(res);
      if (!res.ok) console.error("[GAME] Server error:", body?.detail || res.status);
      return body;
    } catch (err) {
      console.error("[GAME] Backend unreachable — event logged locally only:", err.message);
      return null;
    }
  },

  logEvent: (eventType, data) => {
    console.log(`[LOG] ${eventType}:`, data);
  },

  // ─── Camera (disabled in simulation) ───────────────────────────────────
  sendVideoFrame: () => {},
  sendAudioChunk: () => {},
  detectEmotion: async () => null,
  calibrateBaseline: async () => ({ success: true }),
};

export default HardwareAPI;
